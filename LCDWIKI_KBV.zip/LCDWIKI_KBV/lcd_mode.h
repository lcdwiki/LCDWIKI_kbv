#ifndef _lcd_mode_
#define _lcd_mode_

//if using 8bit mode,set the below macro definition to 1
//if using 16bit mode,set the below macro definition to 0
#define CONFIG_USE_8BIT_BUS 1

#endif // _mcu_pin_magic_
